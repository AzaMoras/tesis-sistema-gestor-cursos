---
name: Academic Editorial Minimal
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#49473d'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#7a776b'
  outline-variant: '#cbc6b9'
  surface-tint: '#645f3e'
  primary: '#5c5838'
  on-primary: '#ffffff'
  primary-container: '#75704e'
  on-primary-container: '#fcf5ca'
  inverse-primary: '#cec79f'
  secondary: '#496366'
  on-secondary: '#ffffff'
  secondary-container: '#c9e5e8'
  on-secondary-container: '#4d676a'
  tertiary: '#395d5b'
  on-tertiary: '#ffffff'
  tertiary-container: '#517674'
  on-tertiary-container: '#d4fcf9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ebe3ba'
  primary-fixed-dim: '#cec79f'
  on-primary-fixed: '#1f1c03'
  on-primary-fixed-variant: '#4b4729'
  secondary-fixed: '#cce8eb'
  secondary-fixed-dim: '#b0cccf'
  on-secondary-fixed: '#041f22'
  on-secondary-fixed-variant: '#314b4e'
  tertiary-fixed: '#c3eae7'
  tertiary-fixed-dim: '#a7cecb'
  on-tertiary-fixed: '#00201f'
  on-tertiary-fixed-variant: '#284d4b'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
typography:
  display-hero:
    fontFamily: Noto Serif
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Noto Serif
    fontSize: 26px
    fontWeight: '500'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Noto Serif
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  title-editorial:
    fontFamily: Noto Serif
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Manrope
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Manrope
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Manrope
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  ui-sans-medium:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  badge-accent:
    fontFamily: Quicksand
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  caption-caps:
    fontFamily: Quicksand
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies the rigor, prestige, and quiet authority of an elite academic institution adapted for modern digital education. The aesthetic pairs classical scholarly publishing with the clarity and discipline of contemporary Swiss minimalism.

### Key Brand Characteristics
- **Scholarly Authority:** Evokes fine paper, archival bindings, and peer-reviewed journals without feeling antiquated or pedantic.
- **Architectural Clarity:** Generous whitespace, precise horizontal alignments, and an uncluttered canvas allow dense academic curricula, syllabi, and matriculation workflows to feel manageable and dignifying.
- **Restraint & Substance:** Every visual element serves an informative purpose. Decorative fluff, flashy animated gradients, emojis, and juvenile micro-interactions are strictly forbidden.
- **Target Audience:** University professors, continuing-education scholars, executive students, and registrar administrators requiring high legibility, unhindered data review, and efficient course enrollments.

## Colors

The palette establishes an intellectual, tactile atmosphere reminiscent of archival reading rooms, balanced against modern digital slate tones.

### Color Roles & Applications
- **Deep Academic Olive (`#75704E`):** Functions as the primary authoritative anchor. Used for primary interactive actions, high-level section titles, selected navigational states, and critical academic milestones.
- **Cool Steel (`#8BA6A9`):** Acts as the secondary functional tone for interactive outlines, secondary callouts, tab indicators, and subdued structural lines.
- **Primary / Light Sky Slate (`#A7CECB`):** Serves as an accent surface tint, active table row highlights, subtle badge fills, and focused state backdrops.
- **Dry Sage (`#CACC90`):** Used sparingly as an accent for academic progress metrics, verified completion seals, and enrollment confirmation states.
- **Warm Surface / Cream (`#F4EBBE`):** Provides delicate warmth for highlighted notices, syllabus callouts, and pinned institutional announcements without high-saturation alarms.
- **Neutrals & Surfaces:**
  - `Canvas Main`: Soft Paper Cream (`#FAFAF7`)
  - `Card / Sheet Background`: Clean White (`#FFFFFF`)
  - `Border / Hairlines`: Crisp Neutral Grey (`#E2E8F0` / `#CBD5E1`)
  - `Body Typography`: Slate Charcoal (`#1E293B`)
  - `Headings & Deep Contrast`: Midnight Slate (`#0F172A`)
  - `Muted Metadata`: Slate Grey (`#64748B`)

## Typography

The typographic hierarchy juxtaposes classical intellectual presence with crisp informational utility:
- **Noto Serif** anchors titles, course catalogues, module names, and formal statements with academic gravitas. It enforces deliberate editorial pacing.
- **Manrope** governs all functional UI contexts: tabular course listings, matriculation step instructions, form inputs, metadata, and body prose, ensuring maximum legibility at dense scales.
- **Quicksand** is reserved strictly for minor accents, status badges, chip indicators, and departmental taxonomy tags, softening dense bureaucratic categories without sacrificing clarity.

## Layout & Spacing

### Architecture & Grid
- **Desktop-First Constraint (1440px):** Content is framed within a disciplined 12-column grid capped at a maximum width of `1440px`, flanked by `margin` margins (`3rem / 48px`). Columns are spaced with `1.5rem (24px)` gutters.
- **Zero Vertical Bars:** The design forbids vertical sidebars, collapsible drawer panels, or floating drawer rails. All navigational, categorical, and procedural hierarchies flow strictly horizontally.
- **Top Sticky Horizontal Navigation:** The primary masthead sits pinned at the top (`h-18` / `72px`), hosting university insignia, primary route links, contextual utility buttons, and user dossier controls in a single clean row.
- **Sub-Navigation & Filters:** Secondary filtering (Faculties, Semesters, Modality) is implemented via horizontal pinned utility strips directly below the masthead or section headers, spanning full grid width.

## Elevation & Depth

This system avoids heavy drop shadows and floating multi-layer elevations in favor of institutional flat precision and low-contrast surface stratification:

- **Border-Driven Separation:** Surfaces and components are distinguished by clean hairlines (`1px solid #E2E8F0` or `#CBD5E1`) rather than high-elevation drop shadows.
- **Tonal Backdrops:** The foundation rests on `#FAFAF7` (Soft Paper Cream), while elevated academic cards, sheets, and inputs rest on `#FFFFFF`.
- **Subtle Ambient Grounding:** For modals and active dropdown menus, use an architectural ambient shadow tinted with slate: `box-shadow: 0 4px 16px -2px rgba(15, 23, 42, 0.06), 0 1px 2px 0 rgba(15, 23, 42, 0.04)`.
- **Focus & Selection Insets:** Highlighting active modules or selected table rows utilizes an inner accent border (`2px inset #75704E`) accompanied by a subtle `#A7CECB1A` background wash.

## Shapes

The shape system is disciplined, tailored, and understated:
- **Level 1 (Soft):** Structural inputs, course cards, data tables, and modal frames use `0.25rem (4px)` radius.
- **Selected Indicators & Chips:** Academic pill-tags for statuses and badges use `0.5rem (8px)` to prevent harshness while avoiding overly playful circular pills.
- **Sharp Technical Accents:** Data grid headers, horizontal dividers, and progress indicator bars feature sharp `0px` edges to evoke printed academic transcripts and architectural blueprints.

## Components

### 1. Horizontal Masthead (Top Sticky Navigation)
- Fixed at the viewport top (`height: 72px`), background `#FFFFFF` with a bottom border `1px solid #E2E8F0`.
- Left-aligned University Crest with institution name rendered in `Noto Serif` (`16px`, weight 600).
- Center horizontal nav items using `Manrope` (`14px`, weight 600) with monochrome Lucide-style SVG icons (`18px`, `stroke-width: 1.75`).
- Active link marked by a bottom border strip (`2px solid #75704E`) rather than pill bubbles.

### 2. Buttons
- **Primary:** Solid `#75704E` fill, `#FFFFFF` text, `4px` corner radius. Subtle hover shift to `#5E5A3D`.
- **Secondary:** Transparent fill with `1px solid #8BA6A9` border, text `#1E293B`. Hover fills with `#A7CECB1F`.
- **Text/Action:** Clean slate text with Lucide chevron icon, underlining only on hover.

### 3. Course Cards
- Background `#FFFFFF`, perimeter hairline `1px solid #E2E8F0`, padding `space-lg (24px)`.
- Academic code in `Quicksand` uppercase (`11px`), course title in `Noto Serif` (`20px`), professor and schedule details in `Manrope` (`13px`).
- Footer housing credit units badge, capacity counter, and an direct enrollment trigger button.

### 4. Chips & Academic Badges
- Rendered in `Quicksand` (`12px`, weight 600).
- **Enrolled / Active:** `#CACC9040` background with `#48452D` text.
- **Prerequisite Pending:** `#F4EBBE` background with `#5E5421` text.
- **Auditing / General:** `#A7CECB33` background with `#2D4F4D` text.

### 5. Inputs & Filter Selectors
- Background `#FAFAF7`, border `1px solid #CBD5E1`, text `#1E293B`, radius `4px`.
- Interactive focus states transition border to `#75704E` with an outline halo of `2px solid #A7CECB4D`. No animated bouncing.

### 6. Course Curriculum & Syllabus Table
- Clean zebra-less ledger: rows separated by `1px solid #E2E8F0`.
- Table headers set in `Manrope` (`12px`, uppercase, tracking `0.06em`, color `#64748B`).
- Row hover produces a soft `#A7CECB0F` tint.